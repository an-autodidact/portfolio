package name.abuchen.portfolio.bootstrap;

public interface ModelConstants // NOSONAR
{
    String PORTFOLIO_PART = "name.abuchen.portfolio.ui.part.portfolio"; //$NON-NLS-1$
    String ERRORLOG_PART = "name.abuchen.portfolio.ui.part.errorlog"; //$NON-NLS-1$
    String PORTFOLIO_PARTSTACK = "name.abuchen.portfolio.ui.partstack.main"; //$NON-NLS-1$

    String BINDING_CONTEXT_PORTFOLIO_FILE = "name.abuchen.portfolio.file"; //$NON-NLS-1$

    String EDITOR_INPUT = "name.abuchen.portfolio.ui.editor.ClientInput"; //$NON-NLS-1$

    String FORCE_CLEAR_PERSISTED_STATE = "model.forceClearPersistedState"; //$NON-NLS-1$

    String E4XMICOPY_FILENAME = "copy.e4xmi"; //$NON-NLS-1$
}
